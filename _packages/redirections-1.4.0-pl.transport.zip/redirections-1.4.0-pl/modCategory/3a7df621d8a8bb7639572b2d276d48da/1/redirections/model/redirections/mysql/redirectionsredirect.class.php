<?php

/**
 * Redirections
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <nodx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/redirectionsredirect.class.php';

class RedirectionsRedirect_mysql extends RedirectionsRedirect
{
}
