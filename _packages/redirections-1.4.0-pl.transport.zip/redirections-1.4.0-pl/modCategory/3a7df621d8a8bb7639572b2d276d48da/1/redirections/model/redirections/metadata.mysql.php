<?php

/**
 * Redirections
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <nodx@oetzie.nl>
 */

$xpdo_meta_map = [
    'xPDOSimpleObject' => [
        'RedirectionsRedirect'
    ]
];
