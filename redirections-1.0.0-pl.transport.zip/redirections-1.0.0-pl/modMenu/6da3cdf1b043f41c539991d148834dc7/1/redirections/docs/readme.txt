----------------------
Redirections
----------------------
Version: 1.0.0
Author: Oene Tjeerd de Bruin
Contact: info@oetzie.nl
----------------------

Redirections gives you a user-friendly interface for managing your site wide
redirects.
